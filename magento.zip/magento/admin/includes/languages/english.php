<?php 
function lang($phrase){
    static $lang= array(
        'HOME_ADMIN'=> 'Home',
        'CATEGORIES'=>'categories',
        'ITEMS'=>'items',
        'MEMBERS'=>'members',
        'COMMENTS'=>'comments',
        'STATIStICS'=>'statistics',
        'LOGS'=>'logs',



    );
return $lang[$phrase];
}
?>