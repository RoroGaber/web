<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
  <style>
    body {
      background:url("layout/images/logo-6.jpg") ;
      background-size: cover;
      background-position: center;
      font-family: Arial, sans-serif;
      color: white; 
      margin: 0;
      padding: 0;
    }

    .contact-form {
      background: #1d1d2138;
      margin: 50px auto;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      max-width: 600px;
    }
    .contact-form h2 {
      margin-bottom: 20px;
      font-size: 36px;
      color: #ffd1d1;
      font-family:italic;
      font-weight:bold;
      text-align: center;
    }
    .contact-form .form-group label {
    font-weight: bold;
    font-size: 20px;
    color: #ffd1d1;
    display: block;
    margin-bottom: 10px;
}

.contact-form .form-group textarea {
    resize: none; /* منع تغيير حجم المربع */
    height: 150px; /* ارتفاع ثابت لصندوق الرسائل */
    border-radius: 8px; /* حواف ناعمة لتتناسب مع باقي الحقول */
    border: 1px solid #ced4da; /* إطار بسيط */
    padding: 10px 15px; /* مسافة داخلية لراحة الكتابة */
    font-size: 16px; /* حجم النص داخل المربع */
    background-color: #f8f9fa63; /* خلفية ناعمة */
    color: #495057; /* لون النص */
    transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out; /* تأثير عند التفاعل */
}

.contact-form .form-group textarea:focus {
    border-color: #007bff; /* لون إطار أزرق عند التركيز */
    box-shadow: 0 0 6px rgba(0, 123, 255, 0.5); /* تأثير ظل */
    background-color: #ffffff; /* خلفية بيضاء */
    color: #212529; /* لون نص أوضح */
}

    .contact-form .form-control {
    border-radius: 8px; /* تقليل الحواف المستديرة ليبدو أكثر أناقة */
    border: 1px solid #ced4da; /* لون إطار بسيط */
    padding: 10px 15px; /* تحسين المسافات الداخلية داخل الحقل */
    font-size: 16px; /* تكبير الخط لتوضيح النص */
    transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out; /* تأثير سلس عند التفاعل */
    margin-bottom: 15px; /* مسافة بين كل عنصر */
    background-color:#f8f9fa63; /* خلفية ناعمة للحقل */
    color: #495057; /* لون النص داخل الحقل */
}

.contact-form .form-control:focus {
    border-color: #007bff; /* تغيير لون الإطار عند التفاعل */
    box-shadow: 0 0 6px rgba(0, 123, 255, 0.5); /* ظل بسيط حول الحقل */
    background-color: #ffffff; /* إبقاء الخلفية بيضاء عند التركيز */
    color: #212529; /* تحسين وضوح النص عند التركيز */
}

.contact-form .form-control::placeholder {
    color: #6c757d; /* لون رمادي ناعم للنص الإرشادي */
    font-style: italic; /* تحسين النص الإرشادي */
}

.contact-form button {
    background: #ffd1d1;
    color: black;
    font-size: 20px;
    font-weight:bold;
    font-family:italic;
    border: none;
    border-radius: 10px;
    padding: 10px 20px;
    transition: background 0.3s ease;
}
    .contact-form button:hover {
      background: #0056b3;
    }
    .contact-form .alert {
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="contact-form">
      <h2>Contact Us</h2>
      <form id="contactForm">
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" id="name" name="name" class="form-control" required>
  </div>
  <div class="form-group">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" class="form-control" required>
  </div>
  <div class="form-group">
    <label for="email">Subject</label>
    <input type="text" id="subject" name="subject" class="form-control" required>
  </div>
  <div class="form-group">
    <label for="message">Message</label>
    <textarea id="message" name="message" class="form-control" required></textarea>
  </div>
  <button type="submit" id="submitForm" class="btn btn-primary">Submit</button>
</form>
<script>
document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // لمنع إرسال النموذج بشكل تقليدي

    // جمع البيانات من المدخلات
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;

    // إنشاء كائن لتخزين البيانات
    const formData = {
      name: name,
      email: email,
      subject: subject,
      message: message
    };

    // تخزين البيانات في localStorage
    localStorage.setItem("contactFormData", JSON.stringify(formData));

    // إظهار رسالة تأكيد
    alert("Your message has been successfully submitted and saved!");

    // إعادة تعيين النموذج بعد الإرسال
    document.getElementById("contactForm").reset();
  });
</script>
    </div>
  </div>
</body>

</html>
