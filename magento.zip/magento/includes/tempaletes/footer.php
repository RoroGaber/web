
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        footer {
            background-color: #337ab7;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 20px;
        }

        .footer-section {
            flex: 1;
            min-width: 200px;
        }

        .footer-section h3 {
            color: #1b1d71;
            padding-bottom: 5px;
            margin-bottom: 10px;
            font-weight:bold;
            font-family:italic;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin: 5px 2px;
            margin-bottom:2px;
        }

        .social-icons a {
            margin: 0 10px;
            display: inline-block;
            color: #fff;
            font-size: 18px;
        }

        .copyright {
            margin-top: 20px;
            font-size: 14px;
        }

        iframe {
            border: 0;
            height: 100px;
        }
    </style>
</head>
<body>

<!-- Footer Section -->
<footer>
    <div class="footer-container">

        <!-- Contact Section -->
        <div class="footer-section contact-info">
            <h3>Contact Us</h3>
            <p>Express</p>
            <p>Email: contact@Express.com</p>
            <p>Phone: +1 234 567 890</p>
            <p>Address: 123 Business Street, City, Country</p>
        </div>

        <!-- Social Media -->
        <div class="footer-section social-media">
    <h3>Follow Us</h3>
    <div class="social-icons">
        <a href="https://www.facebook.com/AliExpress/?locale=ar_AR" target="_blank">
            <i class="fab fa-facebook"></i> Facebook
        </a> 

        <br>
        <a href="https://x.com/AliExpress_EN?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank">
            <i class="fab fa-twitter"></i> Twitter
        </a> 

        <br>
        <a href="https://www.instagram.com/aliexpress/?hl=ar" target="_blank">
            <i class="fab fa-instagram"></i> Instagram
        </a>
    </div>
</div>


        <!-- Map -->
        <div class="footer-section">
            <h3>Our Location</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345090897!2d144.95373531550436!3d-37.81627974202167!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf5776b7f3e2d3c0!2sMelbourne%20VIC%2C%20Australia!5e0!3m2!1sen!2sus!4v1613972405433!5m2!1sen!2sus" allowfullscreen=""></iframe>
        </div>
    </div>

    <!-- Copyright -->
    <div class="copyright">
        &copy; 2024 Express. All Rights Reserved.
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="<?php echo $js?>bootstrap.min.js"></script>
<script src="<?php echo $js?>frontend.js"></script>
</body>
</html>
