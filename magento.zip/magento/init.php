<?php
include 'admin/conect.php';
$sessionUser='';
if(isset($_SESSION['user'])){
    $sessionUser=$_SESSION['user'];
}
$tpl ='includes/tempaletes/';
$css='layout/css/';
$js='layout/js/';
$func='includes/functions/';
include "includes/languages/english.php";
include $func.'functions.php';
include $tpl.'header.php';
include $tpl.'navbar.php';
?>