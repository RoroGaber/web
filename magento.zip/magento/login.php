<?php
session_start();
$pageTitle = 'Login';
if (isset($_SESSION['user'])) {
    header('Location: index.php');
}
include 'init.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['login'])) {
        // Login section
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $hashedpass = sha1($pass); // Hash the password

        // Check the user in the database
        $stmt = $con->prepare("SELECT UserID, Username, Password FROM users WHERE Username = ? AND Password = ?");
        $stmt->execute(array($user, $hashedpass));
        $get=$stmt->fetch();
        $count = $stmt->rowCount();

        if ($count > 0) {
            $_SESSION['user'] = $user;
            $_SESSION['uid'] = $get['UserID'];
            header('Location: index.php');
            exit();
        }
    } else {
        // Registration section
        $formErrors = array();
        
        // Validate username
        if (isset($_POST['username'])) {
            $filterUser = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
            if (strlen($filterUser) < 3) {
                $formErrors[] = 'The Username Must Be Larger Than 3 Characters';
            }
        }

        // Validate passwords
        if (isset($_POST['password']) && isset($_POST['password2'])) {
            if (empty($_POST['password'])) {
                $formErrors[] = 'Sorry, Password Cannot Be Empty';
            } else {
                $pass1 = sha1($_POST['password']);
                $pass2 = sha1($_POST['password2']);
                if ($pass1 !== $pass2) {
                    $formErrors[] = 'Sorry, Passwords Do Not Match';
                } else {
                    $hashedpass = $pass1; // Set the hashed password if they match
                }
            }
        }

        // Validate email
        if (isset($_POST['email'])) {
            $filterEmail = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            if (filter_var($filterEmail, FILTER_VALIDATE_EMAIL) != true) {
                $formErrors[] = 'This Email Is Not Valid';
            }
        }

        // If no errors, proceed with registration
        if (empty($formErrors)) {
            // Check if the username exists
            $check = checkItem("UserName", "users", $filterUser);
            if ($check == 1) {
                $formErrors[] = "Sorry, This User Already Exists";
            } else {
                // Insert new user into the database
                $stmt = $con->prepare("INSERT INTO users (UserName, Password, Email, RegStatus, Date) VALUES (:zuser, :zpass, :zmail, 0, now())");
                $stmt->execute(array(
                    'zuser' => $filterUser,
                    'zpass' => $hashedpass, // Use the hashed password
                    'zmail' => $_POST['email']
                ));

                $successMsg = "Congrats, You Are Now a Registered User";
            }
        }
    }
}
?>
<div class="container login-page">
    <h1 class='text-center'><span class='selected' data-class='login'>Login</span>|<span data-class='signup'>SignUp</span></h1>
    <form class="login" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <div class='input-container'>
            <input class="form-control" type='text' name='username' autocomplete='off' 
            placeholder='Enter Your Username' required='required'/>
        </div>
        <div class='input-container'>
            <input class="form-control" type='password' name='password' autocomplete='new-password' placeholder='Enter Your Password' required='required'/>
        </div>    
        <input class="btn btn-primary btn-block" type='submit' value='Login' name='login'/>
    </form>
    <form class="signup" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <div class='input-container'>
            <input class="form-control" type='text' name='username' autocomplete='off'
            pattern='.{3,}' title='username must be larger than 3 chars'  
            placeholder='Enter Username to sign up with it' required='required'/>
        </div>
        <div class='input-container'>
            <input class="form-control" minlength='4' type='password' name='password' autocomplete='new-password' placeholder='Enter complex Password to sign up with it' required='required'/>
        </div>
        <div class='input-container'>
            <input class="form-control" minlength='4' type='password' name='password2' autocomplete='new-password' placeholder='Enter password again to confirm' required='required'/>
        </div>
        <div class='input-container'>
            <input class="form-control" type='email' name='email' placeholder='Enter a valid email to sign up with it' name='signup' required='required'/>
        </div>
        <input class="btn btn-primary btn-block" type='submit' value='Sign Up'/>
    </form>
    <div class='the-errors text-center'>
        <?php 
        if(!empty($formErrors)){
            foreach($formErrors as $error){
                echo $error.'<br>';
            }
        }
        if(isset($successMsg)){
            echo '<div class="msg-success">'.$successMsg.'</div>';
        }
        ?>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function() {
        $('.signup').hide(); // تأكد أن فورم SignUp مخفية عند بداية التحميل

        $('.login-page h1 span').click(function() {
            $('.login-page h1 span').removeClass('selected'); // إزالة الـ selected من الكل
            $(this).addClass('selected'); // إضافة الـ selected للعنصر الحالي

            if ($(this).data('class') === 'login') {
                $('.signup').hide(); // إخفاء الفورم الأخرى
                $('.login').fadeIn(200); // عرض فورم تسجيل الدخول
            } else {
                $('.login').hide(); // إخفاء فورم تسجيل الدخول
                $('.signup').fadeIn(200); // عرض فورم التسجيل
            }
        });
    });
</script>

