<?php
session_start();
$pageTitle = 'Create New Add';
include 'init.php';

// التحقق من أن المستخدم مسجل دخولاً
if (isset($_SESSION['user'])) {
    // جلب بيانات المستخدم بناءً على الجلسة
    $getUser = $con->prepare("SELECT * FROM users WHERE UserName = ?");
    $getUser->execute(array($_SESSION['user']));
    $info = $getUser->fetch();

    // التأكد من أن معرف المستخدم موجود في الجلسة
    if (isset($_SESSION['uid'])) {
        $userId = $_SESSION['uid'];
    } else {
        // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن معرف المستخدم موجودًا
        header('Location: login.php');
        exit();
    }

    // معالجة طلب POST عند إرسال النموذج
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $formErrors = array();
        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
        $desc = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
        $price = filter_var($_POST['price'], FILTER_SANITIZE_NUMBER_INT);
        $country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);
        $status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT);
        $category = filter_var($_POST['category'], FILTER_SANITIZE_NUMBER_INT);
        $tags = filter_var($_POST['tags'], FILTER_SANITIZE_STRING);

        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $imageName = $_FILES['image']['name'];
            $imageSize = $_FILES['image']['size'];
            $imageTmp  = $_FILES['image']['tmp_name'];
            $imageType = $_FILES['image']['type'];
            $imageAllowExtension = array('jpeg', 'jpg', 'png', 'gif');
            $imageParts = explode('.', $imageName);
            $imageExtension = strtolower(end($imageParts));
        
            if (!in_array($imageExtension, $imageAllowExtension)) {
                $formErrors[] = 'This extension is not allowed';
            }
        
            if ($imageSize > 4194304) {
                $formErrors[] = 'Image cannot be larger than 4MB';
            }
        } else {
            $formErrors[] = 'Image upload failed';
        }

        // التحقق من المدخلات
        if (strlen($name) < 4) {
            $formErrors[] = 'Item Title Must Be At Least 4 chars';
        }
        if (strlen($desc) < 10) {
            $formErrors[] = 'Item Description Must Be At Least 10 chars';
        }
        if (strlen($country) < 3) {
            $formErrors[] = 'Country Must Be At Least 3 chars';
        }
        if (empty($price)) {
            $formErrors[] = 'Item Price Must Not Be Empty';
        }
        if (empty($status)) {
            $formErrors[] = 'Item Status Must Not Be Empty';
        }
        if (empty($category)) {
            $formErrors[] = 'Item Category Must Not Be Empty';
        }

        // إذا لم يكن هناك أخطاء، يتم إدخال الإعلان في قاعدة البيانات
        if (empty($formErrors)) {
            $image = rand(0, 100000) . '_' . $imageName;
            move_uploaded_file($imageTmp, "admin/uploads/items/" . $image);
            $stmt = $con->prepare("INSERT INTO items (Name, Description, Price, Country_Made, Status, Add_Date, Cat_ID, User_ID,Tags,Image) VALUES (:zname, :zdesc, :zprice, :zcountry, :zstatus, now(), :zcat, :zuser,:ztags,:zimage)");
            $stmt->execute(array(
                'zname' => $name,
                'zdesc' => $desc,
                'zprice' => $price,
                'zcountry' => $country,
                'zstatus' => $status,
                'zcat' => $category,
                'zuser' => $userId,
                'ztags'=>$tags,
                'zimage'=>$image
            ));

            if ($stmt) {
                echo '<div class="alert alert-success">Item Added Successfully</div>';
            }
        }
    }
    ?>
    <h1 class='text-center'>Create New Add</h1>
<div class="create-ad block">
    <div class='container'>
        <div class='panel panel-primary'>
            <div class='panel-heading'>
                Create New Add
            </div>
            <div class='panel-body'>
                <div class='row'>
                    <div class='col-md-8'>
                        <form class='form-horizontal main-form' action='<?php echo $_SERVER['PHP_SELF'] ?>' method='POST' enctype='multipart/form-data'>
                            <div class='form-group form-group-lg'>
                                <label class='col-sm-3 control-label'>Name</label>
                                <div class='col-sm-10 col-md-9'>
                                    <input type='text' name='name' class='form-control live-name'  required='required' placeholder='Name Of The Item'/>
                                </div>
                            </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Description</label>
                    <div class='col-sm-10 col-md-9'>
                        <input type='text' name='description' class='form-control live-desc'  placeholder='Description Of The Item'/>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Price</label>
                    <div class='col-sm-10 col-md-9'>
                        <input type='text' name='price' class='form-control live-price'  required='required' placeholder='Price Of The Item '/>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Country</label>
                    <div class='col-sm-10 col-md-9'>
                        <input type='text' name='country' class='form-control'  required='required' placeholder='Country Of Made '/>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Status</label>
                    <div class='col-sm-10 col-md-9'>
                        <select class='form-control' name='status'>
                            <option value='0'>...</option>
                            <option value='1'>New</option>
                            <option value='2'>Like New</option>
                            <option value='3'>Used</option>
                            <option value='4'>Very Old</option>
                        </select>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Category</label>
                    <div class='col-sm-10 col-md-9'>
                        <select class='form-control' name='category'>
                            <option value='0'>...</option>
                            <?php 
                            $cats=getAll('*','categories','','','ID');
                            foreach($cats as $cat){
                                echo '<option value="'.$cat['ID'].'">'.$cat['Name'].'</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Tags</label>
                    <div class='col-sm-10 col-md-9'>
                        <input type='text' name='tags' class='form-control' placeholder='Separate Tags With Comma(,) '/>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <label class='col-sm-3 control-label'>Image Item</label>
                    <div class='col-sm-10 col-md-9'>
                        <input type='file' name='image' class='form-control'  placeholder='Item Image'/>
                    </div>
                </div>
                <div class='form-group form-group-lg'>
                    <div class='col-sm-offset-3 col-sm-10'>
                        <input type='submit' value='Add-Ads ' class='btn btn-primary btn-sm'/>
                    </div>
                </div>
            </form>
                    </div>
                    <div class='col-md-4'>
                        <div class="thumbnail item-box live-preview">
                            <span class="price-tag">$0</span>
                            <img class="image-responsive" src="" alt=""/>
                            <div class="caption">
                                <h3>Title</h3>
                                <p>des.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    if(!empty($formErrors)){
                        foreach($formErrors as $error){
                            echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                    }
                    
                ?>
                </div>
        </div>
    </div>
</div>


    <?php
} else {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل دخول
    header('Location: login.php');
    exit();
}

include $tpl . 'footer.php';

?>