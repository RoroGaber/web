<?php include 'init.php'; ?>
<div class='container'>
    <div class='row'>
    <?php 
    if(isset($_GET['name'])){
        echo "<h1 class='text-center'>".$_GET['name']."</h1>";
        $tag=$_GET['name'];
    $tagsItem = getAll("*","items","where Tags like '%$tag%' ","AND Approve=1","Item_ID"); 
    if (!empty($tagsItem)) {
        foreach ($tagsItem as $item) {
            echo '<div class="col-sm-6 col-md-4">'; // استخدام تقسيم 6 أعمدة للموبايل و4 أعمدة لأجهزة الكمبيوتر
                echo '<div class="thumbnail item-box">';
                    echo '<span class="price-tag">$'.$item['Price'].'</span>';
                    if (!empty($item['Image'])) {
                        echo '<img class="image-responsive" src="admin/uploads/items/' . $item['Image'] . '" alt="' . $item['Name'] . ' Image"/>'; // الصورة من قاعدة البيانات
                    } else {
                        echo '<img class="image-responsive" src="admin/uploads/default.jpg" alt="Default Image"/>'; // صورة افتراضية
                    }
                    echo '<div class="caption">';
                        echo '<h3><a href="items.php?itemid='.$item['Item_ID'].'">'.$item['Name'].'</a></h3>';
                        echo '<p>'.$item['Description'].'</p>';
                        echo '<div class="date">'.$item['Add_Date'].'</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }
    } else {
        echo '<div class="col-12"><p>No items found for this category.</p></div>';
    }
}else{
    echo 'You Must Enter Tag Name';
}
    ?>
    </div>
</div>

<?php include $tpl. 'footer.php';?>